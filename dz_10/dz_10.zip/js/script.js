const calc = createCalculator(1);

function createCalculator(argumentA) {
  let result = argumentA;
  const calcObj = {
    sum: (argumentB) => (result += argumentB),
    mult: (argumentB) => (result *= argumentB),
    div: (argumentB) => (result /= argumentB),
    sub: (argumentB) => (result -= argumentB),
    set: (argumentB) => (result = argumentB),
  };
  return calcObj;
}

calc.sum(5);
calc.mult(6);
calc.div(7);
calc.sub(15);
calc.set(0);
